package com.example.routes.dataStuff

class WallDTO(var wallName: String = "empty", var colorsOnTheWall: MutableList<MyColor> = mutableListOf())