package com.example.routes.saveRouteActivity

import com.example.routes.*
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class SaveRouteActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.save_route_activity)
    }
}